exports.gererPermission = function(req, res, redirection, grade){
    connexion(req, res, redirection);
    permissionRequest(req, res, redirection, grade);
}

var connexion = function(req, res, redirection){
    if(req.session.user == undefined){
        if (redirection !== undefined){
            res.redirect(redirection);
        }
        else{
            res.redirect("/");
        }
    }
}

var permissionRequest = function(req, res, redirection, grade){
    if(require("../../../charlinfo-db/users/users.json")[req.session.user].grade < grade){
        if(redirection !== undefined){
            res.redirect(redirection);
        }
        else{
            res.redirect("/");
        }
    }
}