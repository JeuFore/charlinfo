const {Client} = require('pg');

const client = new Client({
    user: "blessed",
    password: "je95nw62&*",
    host: "localhost",
    port: 5432,
    database: "charlinfo"
});

/**
 * Fonction qui permet de charger les paramètres que l'on passera au générateur de templates
 */
exports.getPugParams = async function(req){
    let obj = {};
    obj.USERS = getUsers();
    obj.COURS = await getCours(req);
    obj.SLUG = getSlugs(req);
    // obj.COURS_INDEX = getCoursIndex(obj);
    obj.NOM_COURS = await getNomCours();
    obj.USER = await getUser(req);
    obj.PERMISSION = await getPermission(obj);
    obj.DATE = getDate();
    obj.CHANGELOG = getChangelog();
    obj.LOGS = getLogs(req)

    return obj;
}

var getDate = function(){
    return (require("./date.js"));
}

var getChangelog = function(){
    return (require("../../../charlinfo-db/changelog/changelog.json"))
}

var getPermission = async function(obj){
    try{
        await client.connect();
        let temp = await client.query("SELECT grade FROM Compte where id = $1", [obj.USER]).rows; // Grade de l'utilisateur
        await client.end();
        return temp;
    } catch (error) {
        return undefined;
    }
}

var getUser = function(req){
    return (req.session.user); // ID de l'utilisateur
}

var getNomCours = async function(){
    await client.connect();
    let temp = await client.query("SELECT * FROM Cours").rows;
    await client.end();
    await console.log("AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA" + temp)
    return temp; // Informations sur tous les cours
}
/**
var getCoursIndex = async function(obj){
    try{
        await client.connect();
        let temp = await client.query("SELECT id FROM Cours WHERE id = obj.slug");
        await client.end();
        let i = 0;
        let tempData = require("../../../charlinfo-db/cours/slugs.json").slugs;
        tempData.sort();
        while(tempData[i] != obj.SLUG){
            i++;
            if(i == tempData.length) throw new Error;
        }
        return i;
    } catch (error) {
        return undefined
    }
}
*/

var getLogs = function(req){
    try{
        return (require("../../../charlinfo-db/users/"+req.params.user+"/logs.json")); // Stocke tous les utilisateurs
    }
    catch (error){
        return undefined;
    }
}

var getUsers = async function(){
    await client.connect();
    let temp = await client.query("SELECT * FROM Compte").rows;
    await client.end();
    return temp; // Informations sur tous les comptes
}

var getSlugs = function(req){
    try{
        return req.params.cours;
    } catch (error) {
        return undefined;
    }
}

var getCours = async function(req){
    try{
        await client.connect();
        let temp = await client.query("SELECT * FROM Cours where id = $1", [req.params.cours]).rows;
        await client.end();
        return temp; // Informations sur le cours
    }
    catch (error) {
        return undefined;
    }
}

exports.requete = async function(requete, args) {
    await client.connect();
    let temp;
    if (args == undefined){
        temp = await client.query(requete);
    }
    else temp = await client.query(requete, args);
    await client.end();
    return await temp.rows;
}
