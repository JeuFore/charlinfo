# Charl'Info

## TODO List

### Beta 1.4)
- Ajouter une limite de taille de fichiers par grade
- Ajouter une interface pour montrer qu'il faut s'inscrire la première fois.
- Ajouter des statistiques sur les Logs (persmission >= 4)

### Beta 1.5)
- Ajouter un moyen d'éditer des fichiers (permission >= 3)
- Ajouter un moyen d'éditer un cours (description, profs, etc...)
- Faire en sorte d'améliorer graphiquement la page de profil

### Beta 1.6)
- Ajout d'un tri possible des fichiers (ordre alphabétique, date de sortie, grade)
- Ajout d'un système de recherche par mot-clé

### Beta 1.7)
- Ajout d'un upload de photo de profil
- Ajout d'une sorte de boîte de mail (+ système serveur qui va avec pour rendre ça simple)
- Ajout d'envoi d'avertissements

### Beta 1.8)
- Amélioration graphique de tout le site
- Ajout de media queries

### Beta 1.9)
- Ajout du système de notation des fichiers

### Beta 1.10)
- Correction de bugs
- Ajout de petites fonctionnalités de dernière minute
- Complétion de la charte
- Attendre un feedback

### 1.0
- Ajout dans le BDD de toute la promo