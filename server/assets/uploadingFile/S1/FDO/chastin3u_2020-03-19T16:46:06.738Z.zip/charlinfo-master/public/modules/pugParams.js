/**
 * Fonction qui permet de charger les paramètres que l'on passera au générateur de templates
 */
exports.getPugParams = function(req){
    let obj = {};
    obj.USERS = getUsers();
    obj.COURS = getCours(req);
    obj.SLUG = getSlugs(req);
    obj.COURS_INDEX = getCoursIndex(obj);
    obj.NOM_COURS = getNomCours();
    obj.USER = getUser(req);
    obj.PERMISSION = getPermission(obj);
    obj.DATE = getDate();
    obj.CHANGELOG = getChangelog();
    obj.LOGS = getLogs(req)

    return obj;
}

var getDate = function(){
    return (require("./date.js"));
}

var getChangelog = function(){
    return (require("../../../charlinfo-db/changelog/changelog.json"))
}

var getPermission = function(obj){
    try{
        let temp = obj.USERS[obj.USER].grade; // Grade de l'utilisateur
        return temp;
    } catch (error) {
        return undefined;
    }
}

var getUser = function(req){
    return (req.session.user); // ID de l'utilisateur
}

var getNomCours = function(){
    return (require("../../../charlinfo-db/cours/cours.json").cours); // Informations sur tous les cours
}

var getCoursIndex = function(obj){
    try{
        let i = 0;
        let tempData = require("../../../charlinfo-db/cours/slugs.json").slugs;
        tempData.sort();
        while(tempData[i] != obj.SLUG){
            i++;
        }
        return i;
    } catch (error) {
        return undefined
    }
}

var getLogs = function(req){
    try{
        return (require("../../../charlinfo-db/users/"+req.params.user+"/logs.json")); // Stocke tous les utilisateurs
    }
    catch (error){
        return undefined;
    }
}

var getUsers = function(){
    return (require("../../../charlinfo-db/users/users.json")); // Stocke tous les utilisateurs
}

var getSlugs = function(req){
    try{
        return req.params.cours;
    } catch (error) {
        return undefined;
    }
}

var getCours = function(req){
    try{
        // Stocke les fichiers du cours où l'on est
        let temp = require("../../../charlinfo-db/cours/"+req.params.cours+"/files.json");
        return temp;
    }
    catch (error) {
        return undefined;
    }
}
