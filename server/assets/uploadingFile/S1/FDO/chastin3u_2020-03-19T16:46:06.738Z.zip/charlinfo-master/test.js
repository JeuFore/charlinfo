const ACTION = require("./public/modules/action.js");
const DATE = require("./public/modules/date.js");

ACTION.ajouterFichier("test/nullll.class");