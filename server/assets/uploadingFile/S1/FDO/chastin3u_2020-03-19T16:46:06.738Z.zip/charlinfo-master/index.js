// Chargement des middlewares
const express = require('express');
const pug = require('pug');
const fs = require('fs');
var fileUpload = require('express-fileupload')
var session = require('cookie-session');
var bodyParser = require('body-parser');
var urlencodedParser = bodyParser.urlencoded({ extended: false });

// Chargement d'Express
var app = express();

// Définit le dossier "public" comme statique (on peut charger du non HTML depuis)
app.use(express.static('public'));

// Définit le repo "charlinfo-db" comme statique, pour faciliter la gestion des données
app.use(express.static('../charlinfo-db'));

// Définit le secret de la session, pour l'initialisation
app.use(session({secret: "superSite"}));

// ---------------------------------------------------------------------------------------------------------------------
// Constantes d'importation de fonctions

/**
 * Fonctions de permissions et de gestion des grades
 */
const PERMISSION = require("./public/modules/permission.js");

/**
 * Fonctions qui génèrent les paramètres pug qui sont nécessaires pour les pages
 */
const PUG_PARAMS = require("./public/modules/pugParams.js");

/**
 * Fonctions pratiques qui se chargent de simplifier et d'alléger le code
 */
const ACTION = require("./public/modules/action.js");

/**
 * Fonctions de gestion des dates
 */
const DATE = require("./public/modules/date.js");

// ---------------------------------------------------------------------------------------------------------------------

// ---------------------------------------------------------------------------------------------------------------------
// Contantes générales

/**
 * Taille limite d'upload de fichier (en Mo)
 */
const TAILLE_LIMITE_UPLOAD_FICHIER = 5.0;

// ---------------------------------------------------------------------------------------------------------------------

/**
 * On initialise le middleware pour l'upload
 */
app.use(fileUpload());

/**
 * Affichage de la charte
 */
app.get("/charte", function(req, res){
    res.setHeader("content-type", "text/html");
    res.render("charte.pug", PUG_PARAMS.getPugParams(req))
});

/**
 * Traitement de la connexion au site
 */
app.post('/connexion/', urlencodedParser, function(req, res) {
    let db = require("../charlinfo-db/users/users.json");
    let userCourant = db[req.body.user]; // Récupère l'ID de l'utilisateur
    if(userCourant !== undefined){ // Si l'utilisateur existe
        if(require('../charlinfo-db/users/hashage/hash.js').hash(req.body.pass) == userCourant.password){ // Si le mot de passe est correct
            req.session.user = req.body.user; // On stocke l'ID de l'utilisateur dans la session
            ACTION.ajouterLogsUtilisateur(req.body.user);
        }
        else{
            req.session.login = "Mot de passe erroné"
        }
    }
    else{
        req.session.login = "Nom d'utilisateur erroné"
    }
    res.redirect('/');
});

/**
 * Traitement de l'inscription au site
 */
app.post('/inscription/', urlencodedParser, function(req, res) {
    let db = require("../charlinfo-db/users/users.json");
    let userCourant = db[req.body.user]; // Récupère l'ID de l'utilisateur
    if(userCourant !== undefined){ // Si l'utilisateur existe en base de données
        if(userCourant.password !== undefined){ // Si le mot de passe est déjà défini
            req.session.sub = "Vous avez déjà un compte"
        }
        else{
            let prenom = req.body.prenom;
            let nom = req.body.nom

            prenom = prenom.toLowerCase();
            let firstLetter = prenom.charAt(0);
            prenom = prenom.replace(firstLetter.toLowerCase(), firstLetter.toUpperCase());
            nom = nom.toUpperCase();

            userCourant.prenom = prenom;
            userCourant.nom = nom;
            userCourant.formation = req.body.formation; // Formation
            userCourant.dateCreation = DATE.dateISO()
            userCourant.password = require('../charlinfo-db/users/hashage/hash.js').hash(req.body.pass); // Stocke le mot de passe encrypté
            userCourant.grade = 1; // Stocke le grade visiteur par défaut
            fs.writeFileSync("../charlinfo-db/users/users.json", JSON.stringify(db)); // Sauvegarde le fichier
            req.session.user = req.body.user; // Connecte l'utilisateur

            ACTION.ajouterLogsUtilisateur(req.body.user);

            res.redirect("/charte");
        }
    }
    else{
        req.session.sub = "Votre compte n'est pas référencé"
    }

    res.redirect('/');
});

/**
 * Construit la page principale
 */
app.get("/", function(req, res){

    if(req.session.user !== undefined){ // Si l'utilisateur est connecté
        req.session.sub = undefined
        res.setHeader("content-type", "text/html");
        res.render("index.pug", PUG_PARAMS.getPugParams(req)); // Charge la page principale
    }
    else{
        res.setHeader("content-type", "text/html");
        res.render("connexion.pug", ACTION.fusionnerEnsembles([{"erreurSub": req.session.sub, "erreurLogin": req.session.login}, PUG_PARAMS.getPugParams(req)]));
    }
});

/**
 * Déconnecte l'utilisateur
 */
app.get("/deconnexion", function(req, res){
    req.session.user = undefined; // Déconnecte l'utilisateur
    res.redirect("/");
})

/**
 * Traitement de l'ajout d'un fichier pour un cours
 */
app.post("/cours/:cours/ajouter/", urlencodedParser, function(req, res){

    PERMISSION.gererPermission(req, res, "/", 1);

    if(req.files.contenu.size > TAILLE_LIMITE_UPLOAD_FICHIER*1000000){
        req.session.tropGros = "Le fichier que vous voulez envoyer est trop gros (il fait "+(Math.round((req.files.contenu.size)/10000)/100)+"Mo alors que la limite est de "+(TAILLE_LIMITE_UPLOAD_FICHIER/1000000)+"Mo)."
        res.redirect("/cours/"+req.params.cours+"/ajout")
    }
    else{
        let fichDB = require("../charlinfo-db/cours/"+req.params.cours+"/files.json"); // Vient chercher tous les fichiers de la matière en question
        app.use(bodyParser({ keepExtensions: true, uploadDir:'../charlinfo-db/cours/'+req.params.cours})); // Configure le fichier où vont être stockés les fichiers

        let last = (req.files.contenu.name).split(".")[((req.files.contenu.name).split(".")).length-1]
        /**
         * Crée l'objet qui répertorie un fichier
         */
        let obj = {};
        obj.nom = req.body.titre;
        obj.description = req.body.desc,
        obj.type = req.body.type;
        obj.auteur = req.session.user;
        obj.date = DATE.dateISO(); // Stocke la date courante au format ISO
        obj.fichier = "/cours/"+req.params.cours+"/["+obj.auteur+"]_"+obj.date+"."+last;
        fichDB['fichiers'].push(obj); // Ajoute au fichier les modifications

        fs.writeFileSync("../charlinfo-db/cours/"+req.params.cours+"/files.json", JSON.stringify(fichDB)); // Sauvegarde le fichier qui répertorie les documents
        fs.writeFileSync("../charlinfo-db/cours/"+req.params.cours+"/["+obj.auteur+"]_"+obj.date+"."+last, req.files.contenu.data); // Sauvegarde le fichier

        ACTION.LogsUploadFichier(req.session.user, req);

        res.redirect("/cours/"+req.params.cours);
    }

});

/**
 * Page où l'on ajoute des cours
 */
app.get("/cours", function(req, res){

    PERMISSION.gererPermission(req, res, "/", 1);

    res.setHeader("content-type", "text/html");
    res.render("cours.pug", PUG_PARAMS.getPugParams(req));
});


/**
 * Page où l'on ajoute des cours
 */
app.get("/cours/ajouter", function(req, res){

    PERMISSION.gererPermission(req, res, "/", 4);

    res.setHeader("content-type", "text/html");
    res.render("ajoutCours.pug", PUG_PARAMS.getPugParams(req));
});

/**
 * Page où l'on supprime des cours
 */
app.get("/cours/supprimer", function(req, res){

    PERMISSION.gererPermission(req, res, "/", 4);

    res.setHeader("content-type", "text/html");
    res.render("supprCours.pug", PUG_PARAMS.getPugParams(req));
});

/**
 * Page où l'on voit les utilisateurs
 */
app.get("/users", function(req, res){

    PERMISSION.gererPermission(req, res, "/", 3);

    res.setHeader("content-type", "text/html");
    res.render("users.pug", PUG_PARAMS.getPugParams(req));
});

/**
 * Page où l'on affiche le cours
 */
app.get("/cours/:cours", function(req, res){

    req.session.tropGros = undefined;

    PERMISSION.gererPermission(req, res, "/", 1);

    res.setHeader("content-type", "text/html");
    res.render("pageCours.pug", PUG_PARAMS.getPugParams(req));
});

/**
 * Processus de suppression d'un cours
 */
app.post("/cours/supprimer/:coursSuppr/", urlencodedParser, function(req, res){

    PERMISSION.gererPermission(req, res, "/", 4);

    ACTION.supprimerDossier("../charlinfo-db/cours/"+req.params.coursSuppr);
    ACTION.supprimerElementTableauJSON("../charlinfo-db/cours/slugs.json", ["slugs"], req.params.coursSuppr);
    ACTION.supprimerObjetTableauJSON("../charlinfo-db/cours/cours.json", ["cours"], "slug", req.params.coursSuppr);

    ACTION.LogsGererCours(req.session.user, req.body.nom, "supprCours");

    res.redirect("/");

});

/**
 * Processus de suppression d'un FICHIER d'un cours
 */
app.get("/cours/:cours/:fichSuppr/:ind/supprimer", urlencodedParser, function(req, res){

    PERMISSION.gererPermission(req, res, "/", 1);
    let pugs = PUG_PARAMS.getPugParams(req);

    if (pugs.USERS[pugs.USER].grade >= 3 || pugs.COURS.fichiers[req.params.ind].auteur == pugs.USER){
        ACTION.LogsSupprimerFichier(req.session.user, pugs.COURS.fichiers[req.params.ind], req);
        ACTION.supprimerFichier("../charlinfo-db/cours/"+req.params.cours+"/"+req.params.fichSuppr);
        ACTION.supprimerObjetTableauJSON("../charlinfo-db/cours/"+req.params.cours+"/files.json", ["fichiers"], "fichier", "/cours/"+req.params.cours+"/"+req.params.fichSuppr);
    }

    res.redirect("/cours/"+req.params.cours);

});

/**
 * Traitement de création d'un cours
 */
app.post("/cours/ajouter/ajout/", urlencodedParser, function(req, res){

    PERMISSION.gererPermission(req, res, "/", 4);

    /**
     * On stocke dans un objet les caractéristiques du cours
     */
    let data = {
        "nom": req.body.nom,
        "description": req.body.desc,
        "professeurs": [],
        "slug": req.body.slug
    };
    let proffs = (req.body.profs).split("|");
    for(let ind in proffs){
        data.professeurs.push(proffs[ind]);
    }


    ACTION.enregistrerElementDansTableauJSON(data, "../charlinfo-db/cours/cours.json", ["cours"]); // On enregistre l'objet dans le fichier de cours.
    ACTION.enregistrerElementDansTableauJSON(req.body.slug, "../charlinfo-db/cours/slugs.json", ["slugs"]); // On met à jour le fichier slug

    ACTION.ajouterDossier("../charlinfo-db/cours/"+req.body.slug); // On crée le dossier de cours
    ACTION.ajouterFichier("../charlinfo-db/cours/"+req.body.slug+"/files.json", JSON.stringify({fichiers:[]})); // On ajout le files.json

    ACTION.LogsGererCours(req.session.user, req.body.nom, "ajoutCours");

    res.redirect('/');
});

/**
 * Page pour ajouter un fichier dans un cours
 */
app.get("/cours/:cours/ajout", function(req, res){

    PERMISSION.gererPermission(req, res, "/", 1);

    res.setHeader("content-type", "text/html");
    res.render("ajoutFichier.pug", ACTION.fusionnerEnsembles([{"erreurTaille": req.session.tropGros}, PUG_PARAMS.getPugParams(req)]));
});

/**
 * Page pour traiter l'ajout d'un utilisateur
 */
app.post("/users/ajouter", urlencodedParser, function(req, res){

    PERMISSION.gererPermission(req, res, "/users", 4);

    ACTION.enregistrerElementDansObjetJSON(req.body.id, {}, "../charlinfo-db/users/users.json", []);
    ACTION.LogsAjouterUtilisateur(req.session.user, req.body.id)

    res.redirect("/users");
});

/**
 * Profil d'un utilisateur
 */
app.get("/users/:user", function(req, res){

    PERMISSION.gererPermission(req, res, "/users", 1);
    let pugs = PUG_PARAMS.getPugParams(req);

    if (pugs.USERS[pugs.USER].grade >= 2 || pugs.USER == req.params.user){
        res.setHeader("content-type", "text/html");
        res.render("user.pug", ACTION.fusionnerEnsembles([{"idUser": req.params.user}, pugs]));
    }
    else{
        res.redirect("/users");
    }

});

/**
 * Page pour BANNIR un utilisateur
 */
app.get("/users/:user/bannir", function(req, res){

    PERMISSION.gererPermission(req, res, "/users", 3);
    let pugs = PUG_PARAMS.getPugParams(req);

    if(pugs.USERS[pugs.USER].grade >= pugs.USERS[req.params.user].grade){
        ACTION.enregistrerElementDansObjetJSON("password", "BANNI", "../charlinfo-db/users/users.json", [req.params.user]);
        ACTION.LogsAdministrer(req.session.user, req.params.user, "BANNIR")
    }

    res.redirect("/users");
});

/**
 * Page pour DEBANNIR un utilisateur
 */
app.get("/users/:user/debannir", function(req, res){

    PERMISSION.gererPermission(req, res, "/users", 3);
    let pugs = PUG_PARAMS.getPugParams(req);

    if(pugs.USERS[pugs.USER].grade >= pugs.USERS[req.params.user].grade && pugs.USERS[req.params.user].password == "BANNI"){
        ACTION.enregistrerElementDansObjetJSON("password", undefined, "../charlinfo-db/users/users.json", [req.params.user]);
        ACTION.LogsAdministrer(req.session.user, req.params.user, "DEBANNIR")
    }

    res.redirect("/users");
});


/**
 * Page pour RETROGRADER un utilisateur
 */
app.get("/users/:user/retrograder", function(req, res){

    PERMISSION.gererPermission(req, res, "/users", 3);
    let pugs = PUG_PARAMS.getPugParams(req);

    if (pugs.USERS[pugs.USER].grade >= pugs.USERS[req.params.user].grade && pugs.USERS[req.params.user].grade > 1){
        ACTION.enregistrerElementDansObjetJSON("grade", (pugs.USERS[req.params.user].grade-1), "../charlinfo-db/users/users.json", [req.params.user]);
        ACTION.LogsAdministrer(req.session.user, req.params.user, "RETROGRADER")
    }

    res.redirect("/users");
});


/**
 * Page pour PROMOUVOIR un utilisateur
 */
app.get("/users/:user/promouvoir", function(req, res){

    PERMISSION.gererPermission(req, res, "/users", 3);
    let pugs = PUG_PARAMS.getPugParams(req);

    if ((pugs.USERS[pugs.USER].grade >= (pugs.USERS[req.params.user].grade+1) || pugs.USERS[pugs.USER].grade >= 5) && pugs.USERS[req.params.user].grade < 5){
        ACTION.enregistrerElementDansObjetJSON("grade", (pugs.USERS[req.params.user].grade+1), "../charlinfo-db/users/users.json", [req.params.user]);
        ACTION.LogsAdministrer(req.session.user, req.params.user, "PROMOUVOIR")
    }

    res.redirect("/users");
});

/**
 * Page pour SUPPRIMER DEFINITIVEMENT un utilisateur
 */
app.get("/users/:user/supprimer", function(req, res){

    PERMISSION.gererPermission(req, res, "/users", 5);

    ACTION.LogsAdministrer(req.session.user, req.params.user, "SUPPRIMER");

    ACTION.supprimerDossier("../charlinfo-db/users/"+req.params.user);
    ACTION.enregistrerElementDansObjetJSON(req.params.user, undefined, "../charlinfo-db/users/users.json", []);

    res.redirect("/users");
});

/**
 * Page pour ajouter un Changelog de mise à jour
 */
app.get("/changelog", function(req, res){

    PERMISSION.gererPermission(req, res, "/", 5);

    res.setHeader("content-type", "text/html");
    res.render("changelog.pug", PUG_PARAMS.getPugParams(req));
});

/**
 * Page pour ajouter un Changelog de mise à jour
 */
app.post("/changelog/ajouter/", urlencodedParser, function(req, res){

    PERMISSION.gererPermission(req, res, "/changelog", 5);

    let obj = {
        "date": DATE.dateISO(),
        "version": req.body.version,
        "changements": []
    }
    let descs = req.body.desc.split(">")
    for (let i in descs){
        obj.changements.push(descs[i])
    }
    ACTION.enregistrerElementDansDebutTableauJSON(obj, "../charlinfo-db/changelog/changelog.json", ["version"])

    res.redirect("/changelog");
});

/**
 * Page pour SUPPRIMER un log
 */
app.get("/users/:user/supprimer/:index", function(req, res){
    PERMISSION.gererPermission(req, res, "/users/"+req.params.user, 4);

    let dateComparer = require("../charlinfo-db/users/"+req.params.user+"/logs.json").logs[req.params.index].date;
    ACTION.supprimerObjetTableauJSON("../charlinfo-db/users/"+req.params.user+"/logs.json", ["logs"], "date", dateComparer);

    res.redirect("/users/"+req.params.user);
});

app.listen(8082);