const en = require('./en.json');
const fr = require('./fr.json');

module.exports = {
  en,
  fr,
};
