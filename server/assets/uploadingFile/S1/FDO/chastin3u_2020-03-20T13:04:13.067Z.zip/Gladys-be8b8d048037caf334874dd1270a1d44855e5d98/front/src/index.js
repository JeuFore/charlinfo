import 'tabler-ui/dist/assets/css/dashboard.css';
import 'dayjs/locale/en';
import 'dayjs/locale/fr';
import './style';
import App from './components/app';

export default App;
