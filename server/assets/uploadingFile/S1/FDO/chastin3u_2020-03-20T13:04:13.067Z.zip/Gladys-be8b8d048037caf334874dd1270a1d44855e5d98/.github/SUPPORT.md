# Getting support from Gladys Community

First, thanks for trying out Gladys!

The best place to ask for help is our [Gladys Community Forum](https://community.gladysassistant.com/).

Please **_do not_** raise an issue on GitHub if it's a support problem!

GitHub issues are used for:

- Bug report
- Feature request

Thanks for being here, see you on the forum 🙏
