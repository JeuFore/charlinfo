const ArmHomeActionParams = ({ children, ...props }) => (
  <select class="form-control">
    <option>Main Home</option>
  </select>
);

export default ArmHomeActionParams;
