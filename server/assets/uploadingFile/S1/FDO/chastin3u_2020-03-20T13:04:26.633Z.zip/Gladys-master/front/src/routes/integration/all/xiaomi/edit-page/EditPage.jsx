import UpdateDevice from '../../../../../components/device';

const EditPage = ({ children, ...props }) => <UpdateDevice {...props} />;

export default EditPage;
