const LockActionParams = ({ children, ...props }) => (
  <select class="form-control">
    <option>Main door</option>
    <option>Bathroom window</option>
  </select>
);

export default LockActionParams;
